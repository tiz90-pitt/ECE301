#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "SafeArray.hpp"

TEST_CASE("Test default construction", "[safearray]")
{
    SafeArray arr;
}