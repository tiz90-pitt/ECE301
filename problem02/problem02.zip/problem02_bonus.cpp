#include <cstdlib>
#include <iostream>

int main()
{

    return EXIT_SUCCESS;
}