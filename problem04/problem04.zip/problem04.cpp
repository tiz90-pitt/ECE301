#include <cstdlib>
#include <iostream>

int main(int argc, char *argv[])
{

    return EXIT_SUCCESS;
}