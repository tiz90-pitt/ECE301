#ifndef _CIRCUITS_HPP
#define _CIRCUITS_HPP

#include <string>

void log_invalid_input()
{
}

double get_value(std::string expr_string)
{
    return 0;
}

double get_current(double resistance, double power)
{
    return 0;
}

double get_resistance(double current, double power)
{
    return 0;
}

double get_power(double current, double resistance)
{
    return 0;
}

double get_divider_power(double source_power, double resistance1, double resistance2)
{
    return 0;
}

#endif