#define CATCH_CONFIG_MAIN
#include "catch.hpp"

TEST_CASE("Test array indexing", "[array-index]")
{
    REQUIRE(true);
}

TEST_CASE("Test array printing", "[array-printing]")
{
    REQUIRE(true);
}

TEST_CASE("Test array addressing", "[array-addressing]")
{
    REQUIRE(true);
}

TEST_CASE("Test array swap", "[array-swap]")
{
    REQUIRE(true);
}

TEST_CASE("Test string swap", "[string-swap]")
{
    REQUIRE(true);
}

TEST_CASE("Test array copy", "[array-copy]")
{
    REQUIRE(true);
}

TEST_CASE("Test array linear search", "[array-search]")
{
    REQUIRE(true);
}

TEST_CASE("Test 2d array (mat) linear search", "[2d-array-search]")
{
    REQUIRE(true);
}

TEST_CASE("Test binary search", "[bi-search]")
{
    REQUIRE(true);
}