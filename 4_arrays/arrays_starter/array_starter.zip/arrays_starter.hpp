#ifndef _ARRAYS_HPP
#define _ARRAYS_HPP

#include <iostream>

#endif