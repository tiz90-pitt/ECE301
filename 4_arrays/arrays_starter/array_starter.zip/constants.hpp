#ifndef _CONSTANTS_HPP
#define _CONSTANTS_HPP

const int COLS = 5;

#endif