// This is circle_area_starter.cpp
// Try cmake . && make && ./circle_area_starter in terminal
// But from now on, use CMake side bar to automate the process

#include <iostream> // due to the usage of cout below

int main()
{
    // radius is 4, calculate and output area as pi*r^2
    std::cout << 3.14 * 4 * 4 << std::endl;
}