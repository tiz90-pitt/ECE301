#include "Database.hpp"

// initialize empty data
Database::Database() : num_entries(0) {}

// initialize with one row of Entry


// initialize with vector


// add function


// remove function


// size function


// is_empty function


// search function


// get_all_entries function


// sort_by_id function


// sort_by_name function
void Database::sort_by_name() {

}

// search_criteria function
int Database::search_criteria(double upper[3]) const {
  return 0;
}
