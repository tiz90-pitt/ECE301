#include <cstdlib>
#include <iostream>

int main()
{
    // TODO: Add your code here
    return EXIT_SUCCESS;
}