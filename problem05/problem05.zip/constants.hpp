#ifndef _CONSTANTS
#define _CONSTANTS

const int CAP = 5;
const double THRESHOLD = 1e-6;

#endif